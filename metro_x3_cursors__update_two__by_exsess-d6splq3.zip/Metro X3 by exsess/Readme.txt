::Name:     Metro X3
::Author:   Rei AJ Browning (DA user: exsess)
::Found at: http://exsess.deviantart.com/art/Metro-X2-Animated-Cursor-Set-267431664

::Updates
Update Two: Nov 7, 2013
+ Improved crispiness and general graphics of all cursors
+ Applied Update One changes to all cursors
+ Changed help cursor from a ! to a ?
+ Made Light cursors truly light without visibility issues on certain backgrounds


Update One: Nov 3, 2013
+ Improved roundedness and crispiness of Busy cursor
+ Changed Working cursor to a less obnoxious, clean icon and animation.


::Install
- Right click on a .inf file located in any one of the folders (ex: Bold->Crimson->Install.inf)* 
 - Select install
- Open Mouse Properties in the Control Panel and go to the pointers tab
- Find the Metro X3 cursors (ex: "Metro X3 Bold-Crimson") in the the drop down and select it**
- Hit apply, then okay
- Leave a comment and enjoy!

Each accent color replaces all of the cursor's original white color you see in the preview box. The only cursors that are unaffected by the accent colors are the links, unavail, pen, and the help cursor's blue circle.
*You can install more than one cursor set at a time!
**The fps in the mouse properties' preview is much slower/choppier than its actual speed.


::Uninstall
- Open Mouse Properties in the Control Panel and go to the pointers tab
- Select the set you want to remove
- Select "Delete" next to the "Save as" button
- Hit apply, then okay
- Navigate to (default) C:/Windows/Cursors/Metro X3 by exsess and delete the cursor set's folder you want to remove
- Make a frowny face :(


::License 
Creative Commons License.
Some rights reserved. This work is licensed under a Creative Commons Attribution-Noncommercial-Share Alike 3.0 License.

You are free:
to Share � to copy, distribute and transmit the work 
to Remix � to adapt the work 

Under the following conditions:
Attribution � You must attribute the work in the manner specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work).  

Noncommercial � You may not use this work for commercial purposes. 

Share Alike � If you alter, transform, or build upon this work, you may distribute the resulting work only under the same or similar license to this one. 

With the understanding that: 
Waiver � Any of the above conditions can be waived if you get permission from the copyright holder. 
Public Domain � Where the work or any of its elements is in the public domain under applicable law, that status is in no way affected by the license. 
Other Rights � In no way are any of the following rights affected by the license: � Your fair dealing or fair use rights, or other applicable copyright exceptions and limitations; 
� The author's moral rights; 
� Rights other persons may have either in the work itself or in how the work is used, such as publicity or privacy rights. 

Notice � For any reuse or distribution, you must make clear to others the license terms of this work. The best way to do this is with a link to this web page. 
